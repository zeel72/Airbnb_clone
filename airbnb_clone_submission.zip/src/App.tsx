import { useState } from 'react';
import { Header } from './components/Header';
import { StickyNav } from './components/StickyNav';
import { ListingHeader } from './components/ListingHeader';
import { HeroGallery } from './components/HeroGallery';
import { ListingContent } from './components/ListingContent';
import { BookingCard } from './components/BookingCard';
import { ReviewsSection } from './components/ReviewsSection';
import { LocationSection } from './components/LocationSection';
import { HostSection } from './components/HostSection';
import { ThingsToKnowSection } from './components/ThingsToKnowSection';
import { Footer } from './components/Footer';
import { PhotoTourModal } from './components/PhotoTourModal';
import { LightboxModal } from './components/LightboxModal';
import { ArchitectureModal } from './components/ArchitectureModal';
import { LISTING_DATA, LISTING_PHOTOS } from './data/listingData';
import './App.css';

export function App() {
  const [isPhotoTourOpen, setIsPhotoTourOpen] = useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxPhotoIndex, setLightboxPhotoIndex] = useState(0);
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);

  const handleOpenPhotoTour = (initialIndex: number = 0) => {
    setIsPhotoTourOpen(true);
    if (initialIndex > 0) {
      setLightboxPhotoIndex(initialIndex);
    }
  };

  const handleOpenLightbox = (index: number) => {
    setLightboxPhotoIndex(index);
    setIsLightboxOpen(true);
  };

  const handleCloseLightbox = () => {
    setIsLightboxOpen(false);
  };

  const handleReserveScroll = () => {
    const el = document.getElementById('booking-card');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="airbnb-app">
      {/* 1. Global Navigation Header */}
      <Header
        onSearchClick={() => {
          const el = document.getElementById('booking-card');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* 2. Sticky Subnav on scroll */}
      <StickyNav
        onReserveClick={handleReserveScroll}
      />

      {/* 3. Main Property Page Container */}
      <main className="listing-page-main">
        <div className="container">
          {/* Listing Title & Actions */}
          <ListingHeader
            title={LISTING_DATA.title}
          />

          {/* Hero 5-Photo Collage */}
          <HeroGallery
            photos={LISTING_PHOTOS}
            onOpenPhotoTour={handleOpenPhotoTour}
          />

          {/* 2-Column Content Grid: Left details + Right sticky booking card */}
          <div className="listing-content-grid">
            <div className="listing-left-col">
              <ListingContent
                onShowAllPhotos={() => handleOpenPhotoTour(0)}
              />
            </div>

            <div className="listing-right-col">
              <BookingCard />
            </div>
          </div>

          <div className="section-divider" />

          {/* Reviews Section with Giant 4.95 Laurel and Metric Columns */}
          <ReviewsSection />

          <div className="section-divider" />

          {/* Location / Interactive Map */}
          <LocationSection />

          <div className="section-divider" />

          {/* Host Profile Section */}
          <HostSection />

          <div className="section-divider" />

          {/* Things to Know Section */}
          <ThingsToKnowSection />
        </div>
      </main>

      {/* 4. Global Footer */}
      <Footer />

      {/* View 2: Full-screen Photo Tour Modal */}
      <PhotoTourModal
        isOpen={isPhotoTourOpen}
        onClose={() => setIsPhotoTourOpen(false)}
        photos={LISTING_PHOTOS}
        onOpenLightbox={handleOpenLightbox}
      />

      {/* View 3: Single-Photo Lightbox Modal */}
      <LightboxModal
        isOpen={isLightboxOpen}
        onClose={handleCloseLightbox}
        photos={LISTING_PHOTOS}
        currentIndex={lightboxPhotoIndex}
        onNavigate={(newIdx) => setLightboxPhotoIndex(newIdx)}
      />

      {/* Architecture Scaling Strategy Modal */}
      <ArchitectureModal
        isOpen={isArchitectureModalOpen}
        onClose={() => setIsArchitectureModalOpen(false)}
      />
    </div>
  );
}

export default App;
