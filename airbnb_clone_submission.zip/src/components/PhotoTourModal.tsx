import React, { useState, useEffect } from 'react';
import type { Photo } from '../data/listingData';
import { ChevronLeft, Share, Heart, Maximize2 } from './Icons';
import './PhotoTourModal.css';

interface PhotoTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  photos: Photo[];
  onOpenLightbox: (photoIndex: number) => void;
}

export const PhotoTourModal: React.FC<PhotoTourModalProps> = ({
  isOpen,
  onClose,
  photos,
  onOpenLightbox,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (isOpen) {
      document.body.classList.add('modal-open');
    } else {
      document.body.classList.remove('modal-open');
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.classList.remove('modal-open');
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Extract unique categories from photos
  const availableCategories = ['All', ...Array.from(new Set(photos.map((p) => p.category)))];

  const filteredPhotos =
    selectedCategory === 'All'
      ? photos
      : photos.filter((p) => p.category === selectedCategory);

  // Group photos by category for 'All' view
  const categoryGroups = availableCategories
    .filter((c) => c !== 'All')
    .map((cat) => ({
      name: cat,
      photos: photos.filter((p) => p.category === cat),
    }));

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      alert('Listing link copied to clipboard!');
    }
  };

  return (
    <div
      className="photo-tour-modal animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-label="Photo tour modal"
    >
      {/* Top Header */}
      <header className="photo-tour-header">
        <div className="container photo-tour-header-container">
          <button
            className="tour-back-btn"
            onClick={onClose}
            aria-label="Back to listing"
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Back to listing</span>
          </button>

          <div className="tour-header-actions">
            <button
              className="action-btn"
              onClick={handleShare}
              aria-label="Share listing"
            >
              <Share className="w-4 h-4" />
              <span>Share</span>
            </button>

            <button
              className={`action-btn ${isSaved ? 'saved' : ''}`}
              onClick={() => setIsSaved(!isSaved)}
              aria-label={isSaved ? 'Remove from wishlist' : 'Save to wishlist'}
            >
              <Heart className={`w-4 h-4 heart-icon ${isSaved ? 'fill-[#FF385C] text-[#FF385C]' : ''}`} />
              <span>{isSaved ? 'Saved' : 'Save'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Categories Navigation Bar */}
      <nav className="photo-tour-category-nav" aria-label="Room categories">
        <div className="container">
          <div className="category-nav-list">
            {availableCategories.map((cat) => {
              const count = cat === 'All' ? photos.length : photos.filter((p) => p.category === cat).length;
              const samplePhoto = photos.find((p) => cat === 'All' || p.category === cat);
              return (
                <button
                  key={cat}
                  className={`category-tab-btn ${selectedCategory === cat ? 'active' : ''}`}
                  onClick={() => setSelectedCategory(cat)}
                  aria-pressed={selectedCategory === cat}
                >
                  {samplePhoto && (
                    <img
                      src={samplePhoto.thumbnail}
                      alt=""
                      className="category-tab-thumb"
                      aria-hidden="true"
                    />
                  )}
                  <span>{cat}</span>
                  <span style={{ opacity: 0.75, fontSize: '12px' }}>({count})</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Photo Content */}
      <main className="photo-tour-body">
        {selectedCategory === 'All' ? (
          categoryGroups.map((group) => {
            if (group.photos.length === 0) return null;
            return (
              <section key={group.name} className="tour-section" id={`tour-section-${group.name}`}>
                <div className="tour-section-header">
                  <h2 className="tour-section-title">{group.name}</h2>
                  <p className="tour-section-desc">
                    {group.name === 'Living room' && 'Spacious air-conditioned living area with romantic lighting and entertainment system.'}
                    {group.name === 'Bedroom' && 'Master bedroom suite with 400TC Egyptian cotton linens and ambient lamps.'}
                    {group.name === 'Jacuzzi' && 'Private in-suite hydrotherapy heated jacuzzi tub with ambient mood lighting.'}
                    {group.name === 'Bathroom' && 'Designer ensuite bathroom with modern rain shower and organic toiletries.'}
                    {group.name === 'Kitchen' && 'Fully equipped modular kitchen, dining bar, and breakfast setting.'}
                    {group.name === 'Exterior' && 'Resort swimming pool, sun deck, garden landscapes, and Candolim surroundings.'}
                  </p>
                </div>

                <div className="tour-photos-grid">
                  {group.photos.map((photo, pIdx) => {
                    const globalIndex = photos.findIndex((p) => p.id === photo.id);
                    const isFullWidth = pIdx % 3 === 0;
                    return (
                      <div
                        key={photo.id}
                        className={`tour-photo-card ${isFullWidth ? 'full-width' : ''}`}
                        onClick={() => onOpenLightbox(globalIndex)}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            onOpenLightbox(globalIndex);
                          }
                        }}
                        aria-label={`Open photo in lightbox: ${photo.title}`}
                      >
                        <div className="tour-photo-img-wrapper">
                          <img
                            src={photo.url}
                            alt={photo.title}
                            className="tour-photo-img"
                            loading="lazy"
                          />
                        </div>
                        <div className="tour-photo-caption-bar">
                          <span className="tour-photo-title">{photo.title}</span>
                          <span className="tour-photo-zoom-hint">
                            <Maximize2 className="w-3.5 h-3.5" />
                            <span>View Fullscreen</span>
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            );
          })
        ) : (
          <section className="tour-section">
            <div className="tour-section-header">
              <h2 className="tour-section-title">{selectedCategory}</h2>
              <p className="tour-section-desc">Showing {filteredPhotos.length} photos</p>
            </div>

            <div className="tour-photos-grid">
              {filteredPhotos.map((photo, pIdx) => {
                const globalIndex = photos.findIndex((p) => p.id === photo.id);
                const isFullWidth = pIdx % 3 === 0;
                return (
                  <div
                    key={photo.id}
                    className={`tour-photo-card ${isFullWidth ? 'full-width' : ''}`}
                    onClick={() => onOpenLightbox(globalIndex)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        onOpenLightbox(globalIndex);
                      }
                    }}
                    aria-label={`Open photo in lightbox: ${photo.title}`}
                  >
                    <div className="tour-photo-img-wrapper">
                      <img
                        src={photo.url}
                        alt={photo.title}
                        className="tour-photo-img"
                        loading="lazy"
                      />
                    </div>
                    <div className="tour-photo-caption-bar">
                      <span className="tour-photo-title">{photo.title}</span>
                      <span className="tour-photo-zoom-hint">
                        <Maximize2 className="w-3.5 h-3.5" />
                        <span>View Fullscreen</span>
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </main>
    </div>
  );
};
