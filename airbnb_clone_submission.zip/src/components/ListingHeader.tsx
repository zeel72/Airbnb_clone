import React, { useState } from 'react';
import { Share, Heart } from './Icons';
import './ListingHeader.css';

interface ListingHeaderProps {
  title: string;
}

export const ListingHeader: React.FC<ListingHeaderProps> = ({ title }) => {
  const [isSaved, setIsSaved] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastText, setToastText] = useState('');

  const triggerToast = (text: string) => {
    setToastText(text);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2500);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      triggerToast('Link copied to clipboard!');
    } else {
      triggerToast('Share URL: ' + window.location.href);
    }
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    triggerToast(!isSaved ? 'Saved to Wishlist' : 'Removed from Wishlist');
  };

  return (
    <div className="listing-header" id="photos">
      <div className="listing-title-row">
        <h1 className="listing-title">{title}</h1>
        <div className="listing-top-actions">
          <button 
            className="action-btn" 
            onClick={handleShare}
            aria-label="Share this listing"
          >
            <Share className="w-4 h-4" />
            <span>Share</span>
          </button>

          <button 
            className={`action-btn ${isSaved ? 'saved' : ''}`} 
            onClick={handleSave}
            aria-label={isSaved ? 'Remove from wishlist' : 'Save to wishlist'}
            aria-pressed={isSaved}
          >
            <Heart className={`w-4 h-4 heart-icon ${isSaved ? 'fill-[#FF385C] text-[#FF385C]' : ''}`} />
            <span>Save</span>
          </button>
        </div>
      </div>

      {showToast && (
        <div className="toast-message" role="status" aria-live="polite">
          {toastText}
        </div>
      )}
    </div>
  );
};
