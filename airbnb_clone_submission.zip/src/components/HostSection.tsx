import React, { useState } from 'react';
import { Award, Clock, ShieldCheck, X } from './Icons';
import { LISTING_DATA } from '../data/listingData';
import './HostSection.css';

export const HostSection: React.FC = () => {
  const { host } = LISTING_DATA;
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messageSent, setMessageSent] = useState(false);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    setMessageSent(true);
    setTimeout(() => {
      setMessageSent(false);
      setMessage('');
      setIsContactModalOpen(false);
    }, 2000);
  };

  return (
    <section className="host-section" aria-labelledby="host-heading">
      <h2 id="host-heading" style={{ fontSize: '22px', fontWeight: 700, marginBottom: '24px' }}>
        Meet your host
      </h2>

      <div className="host-section-card">
        {/* Left Host Profile Card */}
        <div className="host-profile-card">
          <div className="host-big-avatar-wrap">
            <img
              src={host.avatar}
              alt={host.name}
              className="host-big-avatar"
              loading="lazy"
            />
            {host.isSuperhost && (
              <div className="host-big-superhost-badge" title="Superhost">
                <Award className="w-5 h-5 text-white" />
              </div>
            )}
          </div>

          <h3 className="host-name">{host.name}</h3>
          <span className="host-role-badge">Superhost</span>

          <div className="host-stats-row">
            <div className="host-stat-box">
              <span className="host-stat-num">{host.reviews}</span>
              <span className="host-stat-desc">Reviews</span>
            </div>
            <div className="host-stat-box">
              <span className="host-stat-num">
                {host.rating.toFixed(2)} ★
              </span>
              <span className="host-stat-desc">Rating</span>
            </div>
            <div className="host-stat-box">
              <span className="host-stat-num">{host.yearsHosting}</span>
              <span className="host-stat-desc">Years hosting</span>
            </div>
          </div>
        </div>

        {/* Right Host Details */}
        <div className="host-details-col">
          <div>
            <h3 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '8px' }}>
              Host details
            </h3>
            <p className="host-bio-text">{host.bio}</p>

            <div className="host-meta-details-list">
              <div className="host-meta-item">
                <Clock className="w-4 h-4 text-[#717171]" />
                <span>Response rate: {host.responseRate}%</span>
              </div>
              <div className="host-meta-item">
                <Clock className="w-4 h-4 text-[#717171]" />
                <span>Responds {host.responseTime}</span>
              </div>
              <div className="host-meta-item">
                <ShieldCheck className="w-4 h-4 text-[#717171]" />
                <span>Identity verified & licensed hospitality provider</span>
              </div>
            </div>
          </div>

          <div>
            <button
              className="btn-outline"
              onClick={() => setIsContactModalOpen(true)}
            >
              Contact Host
            </button>

            <p className="payment-protection-notice">
              To protect your payment, never transfer money or communicate outside of the Airbnb website or app.
            </p>
          </div>
        </div>
      </div>

      {/* Contact Host Modal */}
      {isContactModalOpen && (
        <div
          className="airbnb-modal-backdrop animate-fade-in"
          onClick={() => setIsContactModalOpen(false)}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="airbnb-modal-container animate-scale-in"
            style={{ maxWidth: '540px' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="airbnb-modal-header">
              <h3 style={{ fontSize: '18px', fontWeight: 700 }}>
                Message {host.name}
              </h3>
              <button
                className="btn-icon"
                onClick={() => setIsContactModalOpen(false)}
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="airbnb-modal-body">
              {messageSent ? (
                <div style={{ textAlign: 'center', padding: '32px 0' }}>
                  <div
                    style={{
                      width: '48px',
                      height: '48px',
                      borderRadius: '50%',
                      background: '#DCFCE7',
                      color: '#16A34A',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      margin: '0 auto 16px',
                    }}
                  >
                    ✓
                  </div>
                  <h4 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '8px' }}>
                    Message sent!
                  </h4>
                  <p style={{ color: 'var(--color-text-secondary)', fontSize: '14px' }}>
                    {host.name} typically responds within an hour.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSendMessage}>
                  <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', marginBottom: '16px' }}>
                    Have questions about Candolim beach proximity, jacuzzi amenities, or special check-in times?
                  </p>
                  <textarea
                    rows={5}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Hi Mirashya, I'm interested in booking your Romantic Jacuzzi 1BHK..."
                    style={{
                      width: '100%',
                      padding: '12px',
                      borderRadius: '8px',
                      border: '1px solid var(--color-border-dark)',
                      resize: 'none',
                      fontSize: '14px',
                      marginBottom: '16px',
                    }}
                    required
                  />
                  <button type="submit" className="btn-primary">
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
