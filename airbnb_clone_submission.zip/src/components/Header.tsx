import React, { useState, useRef, useEffect } from 'react';
import { AirbnbLogo, Search, Globe, Menu, User } from './Icons';
import './Header.css';

interface HeaderProps {
  onSearchClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSearchClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className={`site-header ${isScrolled ? 'scrolled' : ''}`}>
      <div className="container header-container">
        {/* Brand Logo */}
        <div 
          className="header-brand" 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          role="button"
          tabIndex={0}
          aria-label="Airbnb Home"
        >
          <AirbnbLogo className="h-8 text-[#FF385C]" />
          <span className="header-brand-name">airbnb</span>
        </div>

        {/* Center Search Bar matching reference */}
        <div 
          className="header-search" 
          onClick={onSearchClick}
          role="button"
          tabIndex={0}
          aria-label="Search destinations, dates, and guests"
        >
          {/* House icon inside pill */}
          <div className="search-house-icon">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
              <path d="M3 10.5L12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1v-9.5z" fill="#E2E8F0" stroke="#475569" strokeWidth="1.5" />
              <rect x="7" y="11" width="3" height="3" fill="#38BDF8" rx="0.5" />
              <rect x="14" y="11" width="3" height="3" fill="#38BDF8" rx="0.5" />
              <path d="M10 21v-4h4v4" fill="#64748B" />
              <path d="M12 2l-10 8.5 1.4 1.6L12 4.8l8.6 7.3 1.4-1.6L12 2z" fill="#DC2626" />
            </svg>
          </div>

          <span className="search-segment">Anywhere</span>
          <span className="search-divider" aria-hidden="true" />
          <span className="search-segment">Anytime</span>
          <span className="search-divider" aria-hidden="true" />
          <span className="search-segment muted">Add guests</span>
          <div className="search-icon-btn">
            <Search className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
        </div>

        {/* Right Navigation */}
        <div className="header-actions">
          <button className="btn-host" aria-label="Become a host">
            Become a host
          </button>

          <button className="btn-icon" aria-label="Choose language and currency">
            <Globe className="w-4 h-4 text-[#222222]" />
          </button>

          {/* User Menu */}
          <div style={{ position: 'relative' }} ref={dropdownRef}>
            <button 
              className="user-menu-btn" 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              aria-expanded={isDropdownOpen}
              aria-label="Main navigation menu"
            >
              <Menu className="w-4 h-4 text-[#222222]" />
              <div className="user-avatar-circle">
                <User className="w-4 h-4" />
              </div>
            </button>

            {isDropdownOpen && (
              <div className="user-dropdown" role="menu">
                <button className="dropdown-item bold" role="menuitem">Sign up</button>
                <button className="dropdown-item" role="menuitem">Log in</button>
                <div className="dropdown-divider" />
                <button className="dropdown-item" role="menuitem">Airbnb your home</button>
                <button className="dropdown-item" role="menuitem">Host an experience</button>
                <button className="dropdown-item" role="menuitem">Help Center</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
