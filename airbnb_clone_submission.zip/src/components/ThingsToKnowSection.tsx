import React, { useState } from 'react';
import {
  Clock,
  Users,
  Ban,
  PawPrint,
  VolumeX,
  Camera,
  Flame,
  AlertCircle,
  Cross,
  CheckCircle,
  Info,
  FileText,
  ChevronRight,
  X,
} from './Icons';
import { LISTING_DATA } from '../data/listingData';
import './ThingsToKnowSection.css';

export const ThingsToKnowSection: React.FC = () => {
  const { thingsToKnow } = LISTING_DATA;
  const [modalTopic, setModalTopic] = useState<string | null>(null);

  const renderIcon = (name: string) => {
    switch (name) {
      case 'Clock': return <Clock className="w-4 h-4 things-item-icon" />;
      case 'Users': return <Users className="w-4 h-4 things-item-icon" />;
      case 'Ban': return <Ban className="w-4 h-4 things-item-icon" />;
      case 'PawPrint': return <PawPrint className="w-4 h-4 things-item-icon" />;
      case 'VolumeX': return <VolumeX className="w-4 h-4 things-item-icon" />;
      case 'Camera': return <Camera className="w-4 h-4 things-item-icon" />;
      case 'Flame': return <Flame className="w-4 h-4 things-item-icon" />;
      case 'AlertCircle': return <AlertCircle className="w-4 h-4 things-item-icon" />;
      case 'Cross': return <Cross className="w-4 h-4 things-item-icon" />;
      case 'CheckCircle': return <CheckCircle className="w-4 h-4 things-item-icon" />;
      case 'Info': return <Info className="w-4 h-4 things-item-icon" />;
      case 'FileText': return <FileText className="w-4 h-4 things-item-icon" />;
      default: return <Info className="w-4 h-4 things-item-icon" />;
    }
  };

  return (
    <section className="things-section" aria-labelledby="things-heading">
      <h2 id="things-heading" className="things-title">
        Things to know
      </h2>

      <div className="things-grid">
        {/* House Rules */}
        <div className="things-col">
          <h3 className="things-col-title">House rules</h3>
          <div className="things-items-list">
            {thingsToKnow.houseRules.slice(0, 3).map((r, i) => (
              <div key={i} className="things-item-row">
                {renderIcon(r.icon)}
                <span>{r.text}</span>
              </div>
            ))}
          </div>
          <button
            className="things-show-more-link"
            onClick={() => setModalTopic('House rules')}
          >
            <span>Show more</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Safety & Property */}
        <div className="things-col">
          <h3 className="things-col-title">Safety & property</h3>
          <div className="things-items-list">
            {thingsToKnow.safetyAndProperty.slice(0, 3).map((s, i) => (
              <div key={i} className="things-item-row">
                {renderIcon(s.icon)}
                <span>{s.text}</span>
              </div>
            ))}
          </div>
          <button
            className="things-show-more-link"
            onClick={() => setModalTopic('Safety & property')}
          >
            <span>Show more</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Cancellation Policy */}
        <div className="things-col">
          <h3 className="things-col-title">Cancellation policy</h3>
          <div className="things-items-list">
            {thingsToKnow.cancellationPolicy.slice(0, 2).map((c, i) => (
              <div key={i} className="things-item-row">
                {renderIcon(c.icon)}
                <span>{c.text}</span>
              </div>
            ))}
          </div>
          <button
            className="things-show-more-link"
            onClick={() => setModalTopic('Cancellation policy')}
          >
            <span>Show more</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Details Modal */}
      {modalTopic && (
        <div
          className="airbnb-modal-backdrop animate-fade-in"
          onClick={() => setModalTopic(null)}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="airbnb-modal-container animate-scale-in"
            style={{ maxWidth: '580px' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="airbnb-modal-header">
              <h3 style={{ fontSize: '18px', fontWeight: 700 }}>{modalTopic}</h3>
              <button
                className="btn-icon"
                onClick={() => setModalTopic(null)}
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="airbnb-modal-body">
              {modalTopic === 'House rules' && (
                <div className="things-items-list">
                  {thingsToKnow.houseRules.map((r, i) => (
                    <div key={i} className="things-item-row" style={{ padding: '8px 0' }}>
                      {renderIcon(r.icon)}
                      <span>{r.text}</span>
                    </div>
                  ))}
                </div>
              )}

              {modalTopic === 'Safety & property' && (
                <div className="things-items-list">
                  {thingsToKnow.safetyAndProperty.map((s, i) => (
                    <div key={i} className="things-item-row" style={{ padding: '8px 0' }}>
                      {renderIcon(s.icon)}
                      <span>{s.text}</span>
                    </div>
                  ))}
                </div>
              )}

              {modalTopic === 'Cancellation policy' && (
                <div className="things-items-list">
                  {thingsToKnow.cancellationPolicy.map((c, i) => (
                    <div key={i} className="things-item-row" style={{ padding: '8px 0' }}>
                      {renderIcon(c.icon)}
                      <span>{c.text}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
