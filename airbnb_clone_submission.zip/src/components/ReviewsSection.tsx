import React from 'react';
import { Star } from './Icons';
import { LISTING_DATA } from '../data/listingData';
import './ReviewsSection.css';

export const ReviewsSection: React.FC = () => {
  const { ratingBreakdown, reviews, reviewTags } = LISTING_DATA;

  return (
    <section className="reviews-section" id="reviews" aria-labelledby="reviews-heading">
      {/* Giant 4.95 Laurel Wreath Header (Matching Reference Screenshot 5) */}
      <div className="reviews-hero-wreath-header">
        <div className="wreath-score-container">
          {/* Left Wreath Branch */}
          <svg className="wreath-large-svg" viewBox="0 0 40 80" fill="currentColor">
            <path d="M36 4c-3 8-7 16-12 24-5 8-11 16-16 25-2 4-4 8-4 13 0 6 3 11 8 13 4 2 9 1 13-2 5-4 8-10 9-16 1-7-1-14-3-21-3-12-8-24-15-34-1-1 0-3 1-3 1 0 2 0 3 1 7 11 13 23 16 36 2 7 3 15 2 22-1 7-5 14-11 18-5 4-12 5-17 2-6-3-9-9-9-16 0-6 2-11 5-15 6-10 12-18 17-27 5-9 9-18 13-28 1-2 3-1 4 1z" />
          </svg>

          <span className="giant-rating-num">4.95</span>

          {/* Right Wreath Branch */}
          <svg className="wreath-large-svg" viewBox="0 0 40 80" fill="currentColor" style={{ transform: 'scaleX(-1)' }}>
            <path d="M36 4c-3 8-7 16-12 24-5 8-11 16-16 25-2 4-4 8-4 13 0 6 3 11 8 13 4 2 9 1 13-2 5-4 8-10 9-16 1-7-1-14-3-21-3-12-8-24-15-34-1-1 0-3 1-3 1 0 2 0 3 1 7 11 13 23 16 36 2 7 3 15 2 22-1 7-5 14-11 18-5 4-12 5-17 2-6-3-9-9-9-16 0-6 2-11 5-15 6-10 12-18 17-27 5-9 9-18 13-28 1-2 3-1 4 1z" />
          </svg>
        </div>

        <h3 className="reviews-gf-title">Guest favourite</h3>
        <p className="reviews-gf-subtext">
          This home is a guest favourite based on ratings, reviews and reliability
        </p>
        <span className="reviews-how-it-works-link">How reviews work</span>
      </div>

      {/* Horizontal Category Score Columns (Matching Reference Screenshot 5) */}
      <div className="reviews-metrics-horizontal-row">
        {/* Overall rating bar chart */}
        <div className="metric-col-overall">
          <span className="metric-col-title">Overall rating</span>
          {[5, 4, 3, 2, 1].map((star) => (
            <div key={star} className="overall-bar-row">
              <span>{star}</span>
              <div className="overall-bar-track">
                <div
                  className="overall-bar-fill"
                  style={{ width: star === 5 ? '95%' : star === 4 ? '5%' : '0%' }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Cleanliness (Spray bottle icon) */}
        <div className="metric-col-item">
          <span className="metric-col-title">Cleanliness</span>
          <span className="metric-item-num">{ratingBreakdown.cleanliness.toFixed(1)}</span>
          <svg className="metric-item-icon" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.75">
            <path d="M12 4h4v5h-4z" />
            <path d="M8 9h12l-1 19H9L8 9z" />
            <path d="M16 6v3" />
            <path d="M6 9h3" />
            <circle cx="24" cy="7" r="1.5" fill="currentColor" />
            <circle cx="27" cy="11" r="1" fill="currentColor" />
          </svg>
        </div>

        {/* Accuracy (Checkmark circle) */}
        <div className="metric-col-item">
          <span className="metric-col-title">Accuracy</span>
          <span className="metric-item-num">{ratingBreakdown.accuracy.toFixed(1)}</span>
          <svg className="metric-item-icon" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.75">
            <circle cx="16" cy="16" r="12" />
            <path d="M10 16l4 4 8-8" />
          </svg>
        </div>

        {/* Check-in (Key icon) */}
        <div className="metric-col-item">
          <span className="metric-col-title">Check-in</span>
          <span className="metric-item-num">{ratingBreakdown.checkIn.toFixed(1)}</span>
          <svg className="metric-item-icon" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.75">
            <circle cx="20" cy="12" r="6" />
            <path d="M15 16L6 25v3h3l2-2v-2h2l2-2" />
          </svg>
        </div>

        {/* Communication (Chat bubble icon) */}
        <div className="metric-col-item">
          <span className="metric-col-title">Communication</span>
          <span className="metric-item-num">{ratingBreakdown.communication.toFixed(1)}</span>
          <svg className="metric-item-icon" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.75">
            <path d="M5 8a3 3 0 0 1 3-3h16a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H11l-5 4v-4H8a3 3 0 0 1-3-3V8z" />
          </svg>
        </div>

        {/* Location (Folded map icon) */}
        <div className="metric-col-item">
          <span className="metric-col-title">Location</span>
          <span className="metric-item-num">{ratingBreakdown.location.toFixed(1)}</span>
          <svg className="metric-item-icon" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.75">
            <path d="M5 8l7-4 8 4 7-4v20l-7 4-8-4-7 4V8z" />
            <path d="M12 4v20" />
            <path d="M20 8v20" />
          </svg>
        </div>

        {/* Value (Price tag icon) */}
        <div className="metric-col-item">
          <span className="metric-col-title">Value</span>
          <span className="metric-item-num">{ratingBreakdown.value.toFixed(1)}</span>
          <svg className="metric-item-icon" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.75">
            <path d="M24 6l-9 9-9-9H6v6l9 9 9-9V6h-6z" transform="rotate(45 16 16)" />
            <circle cx="10" cy="10" r="1.5" fill="currentColor" />
          </svg>
        </div>
      </div>

      {/* Review Tags Filter Pills (Matching Reference Screenshot 5) */}
      <div className="review-tags-scroll-row">
        {reviewTags.map((tag) => (
          <button key={tag.name} className="review-tag-pill">
            <span>{tag.emoji}</span>
            <span>{tag.name}</span>
            <span className="count">{tag.count}</span>
          </button>
        ))}
      </div>

      {/* Reviews Cards Grid (Matching Reference Screenshot 5) */}
      <div className="reviews-grid-2col">
        {reviews.map((rev) => (
          <article key={rev.id} className="review-card-item">
            <div className="reviewer-user-row">
              {rev.avatarLetter ? (
                <div className="reviewer-avatar-letter">{rev.avatarLetter}</div>
              ) : (
                <img
                  src={rev.avatar}
                  alt={rev.author}
                  className="reviewer-avatar-img"
                  loading="lazy"
                />
              )}
              <div>
                <h4 className="reviewer-name-h4">{rev.author}</h4>
                <p className="reviewer-tenure-p">{rev.stayDuration}</p>
              </div>
            </div>

            <div className="review-stars-line">
              <div style={{ display: 'flex', gap: '2px' }}>
                {Array.from({ length: rev.rating }).map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-current text-[#222222]" />
                ))}
              </div>
              <span>·</span>
              <span style={{ fontWeight: 600 }}>{rev.date}</span>
            </div>

            <p className="review-body-text">{rev.content}</p>
          </article>
        ))}
      </div>
    </section>
  );
};
