import React, { useState } from 'react';
import { Plus, Minus, AirbnbLogo } from './Icons';
import { LISTING_DATA } from '../data/listingData';
import './LocationSection.css';

export const LocationSection: React.FC = () => {
  const [mapType, setMapType] = useState<'map' | 'satellite'>('map');
  const [zoomLevel, setZoomLevel] = useState<number>(14);

  return (
    <section className="location-section" id="location" aria-labelledby="location-heading">
      <h2 className="location-title" id="location-heading">
        Where you'll be
      </h2>
      <p className="location-subtitle">
        {LISTING_DATA.location.city}, {LISTING_DATA.location.state}, {LISTING_DATA.location.country}
      </p>

      {/* Interactive Map Component */}
      <div className="interactive-map-container" role="region" aria-label="Location map of Candolim Goa">
        {/* SVG Rendered Map Terrain */}
        <svg
          className="map-svg-background"
          viewBox="0 0 1000 600"
          preserveAspectRatio="xMidYMid slice"
        >
          {/* Ocean / Arabian Sea */}
          <rect width="1000" height="600" fill={mapType === 'map' ? '#CAD2D3' : '#172B36'} />
          
          {/* Coastline & Landmass */}
          <path
            d="M 320 0 Q 360 180 340 300 T 380 600 L 1000 600 L 1000 0 Z"
            fill={mapType === 'map' ? '#F4F3F0' : '#2D4336'}
          />

          {/* Beach strip */}
          <path
            d="M 315 0 Q 355 180 335 300 T 375 600 L 400 600 Q 360 300 340 0 Z"
            fill={mapType === 'map' ? '#FFE8B5' : '#D4B886'}
            opacity="0.8"
          />

          {/* Tropical Green Patches */}
          <circle cx="580" cy="180" r="140" fill={mapType === 'map' ? '#D5E8D4' : '#1F382B'} opacity="0.6" />
          <circle cx="780" cy="380" r="180" fill={mapType === 'map' ? '#D5E8D4' : '#1F382B'} opacity="0.6" />
          <circle cx="480" cy="460" r="110" fill={mapType === 'map' ? '#D5E8D4' : '#1F382B'} opacity="0.6" />

          {/* Road Network */}
          <path
            d="M 420 0 L 440 600"
            stroke={mapType === 'map' ? '#FFFFFF' : '#475569'}
            strokeWidth="10"
            strokeLinecap="round"
          />
          <path
            d="M 420 0 L 440 600"
            stroke={mapType === 'map' ? '#FED7AA' : '#334155'}
            strokeWidth="6"
            strokeLinecap="round"
          />
          {/* Arterial roads */}
          <path
            d="M 430 180 Q 600 210 900 150"
            stroke={mapType === 'map' ? '#FFFFFF' : '#475569'}
            strokeWidth="8"
          />
          <path
            d="M 435 320 Q 620 300 950 360"
            stroke={mapType === 'map' ? '#FFFFFF' : '#475569'}
            strokeWidth="8"
          />
          <path
            d="M 440 450 Q 560 480 880 520"
            stroke={mapType === 'map' ? '#FFFFFF' : '#475569'}
            strokeWidth="8"
          />

          {/* Geographic Labels */}
          <text x="120" y="300" fill={mapType === 'map' ? '#4A6B82' : '#94A3B8'} fontSize="18" fontWeight="600" letterSpacing="3">
            ARABIAN SEA
          </text>
          <text x="310" y="240" fill="#92400E" fontSize="13" fontWeight="600" transform="rotate(-78 310 240)">
            Candolim Beach (800m)
          </text>
          <text x="460" y="160" fill="#475569" fontSize="14" fontWeight="600">
            Fort Aguada Road
          </text>
          <text x="750" y="320" fill="#475569" fontSize="15" fontWeight="600">
            Candolim Village & Markets
          </text>
        </svg>

        {/* Pulsing Location Pin */}
        <div className="map-pin-pulse">
          <div className="pin-circle">
            <AirbnbLogo className="w-7 h-7 text-white" />
          </div>
          <div className="pin-bubble-card">
            Mirashya UG10 · Candolim
          </div>
        </div>

        {/* Map Type Toggle (Map vs Satellite) */}
        <div className="map-type-toggle">
          <button
            className={`map-type-btn ${mapType === 'map' ? 'active' : ''}`}
            onClick={() => setMapType('map')}
          >
            Map
          </button>
          <button
            className={`map-type-btn ${mapType === 'satellite' ? 'active' : ''}`}
            onClick={() => setMapType('satellite')}
          >
            Satellite
          </button>
        </div>

        {/* Zoom Controls */}
        <div className="map-controls-group">
          <button
            className="map-control-btn"
            onClick={() => setZoomLevel(Math.min(zoomLevel + 1, 18))}
            aria-label="Zoom in"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            className="map-control-btn"
            onClick={() => setZoomLevel(Math.max(zoomLevel - 1, 10))}
            aria-label="Zoom out"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="neighborhood-info-block">
        <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '6px' }}>
          Candolim, Goa, India
        </h3>
        <p>
          Candolim is celebrated for its serene beaches, upscale dining, and vibrant yet peaceful Goan charm. 
          Mirashya UG10 is tucked in a tranquil residential lane just 800 meters from the sand. 
          You can stroll to beach shacks like Calamari and Fisherman's Cove, discover local bakeries and supermarkets within 300 meters, 
          and reach historical Fort Aguada and Sinquerim Beach in less than 5 minutes by scooter or cab.
        </p>
      </div>
    </section>
  );
};
