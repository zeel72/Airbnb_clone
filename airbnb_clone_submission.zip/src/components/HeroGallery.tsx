import React from 'react';
import type { Photo } from '../data/listingData';
import { DotGridIcon } from './Icons';
import './HeroGallery.css';

interface HeroGalleryProps {
  photos: Photo[];
  onOpenPhotoTour: (initialIndex?: number) => void;
}

export const HeroGallery: React.FC<HeroGalleryProps> = ({ photos, onOpenPhotoTour }) => {
  const heroPhotos = photos.slice(0, 5);

  return (
    <section className="hero-gallery" id="hero-gallery" aria-label="Photo gallery preview">
      <div className="hero-grid">
        {heroPhotos.map((photo, index) => (
          <div
            key={photo.id}
            className={`hero-item ${index === 0 ? 'primary' : ''}`}
            onClick={() => onOpenPhotoTour(index)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onOpenPhotoTour(index);
              }
            }}
            aria-label={`View photo ${index + 1}: ${photo.title}`}
          >
            <img
              src={photo.url}
              alt={photo.title}
              className="hero-img"
              loading={index === 0 ? 'eager' : 'lazy'}
            />
            <div className="hero-overlay" />
          </div>
        ))}
      </div>

      <button
        className="show-all-photos-btn"
        onClick={() => onOpenPhotoTour(0)}
        aria-label="Show all photos"
      >
        <DotGridIcon className="w-4 h-4" />
        <span>Show all photos</span>
      </button>
    </section>
  );
};
