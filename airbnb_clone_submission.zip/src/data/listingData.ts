export interface Photo {
  id: number;
  url: string;
  thumbnail: string;
  category: 'Living room' | 'Bedroom' | 'Bathroom' | 'Jacuzzi' | 'Kitchen' | 'Exterior';
  title: string;
  description: string;
}

export interface Review {
  id: string;
  author: string;
  avatar?: string;
  avatarLetter?: string;
  rating: number;
  date: string;
  stayDuration: string;
  content: string;
}

export interface AmenityItem {
  name: string;
  category: string;
  available: boolean;
  icon: string;
}

export const LISTING_DATA = {
  id: 'mirashya-ug10-candolim',
  title: 'Romantic Jacuzzi 1BHK Candolim | Mirashya UG10',
  type: 'Entire serviced apartment in Candolim, India',
  stats: {
    guests: 3,
    bedrooms: 1,
    beds: 1,
    baths: 1,
  },
  rating: 4.95,
  reviewCount: 19,
  isGuestFavorite: true,
  priceTotal: 28499,
  totalNights: 5,
  checkInDate: '10/18/2026',
  checkOutDate: '10/23/2026',
  cancellationDeadline: '17 October',
  location: {
    city: 'Candolim',
    state: 'Goa',
    country: 'India',
  },
  host: {
    name: 'Mirashya Homes',
    avatar: '/images/host-avatar.png',
    isSuperhost: true,
    rating: 4.95,
    reviews: 19,
    yearsHosting: 2,
    responseTime: 'within an hour',
    responseRate: 100,
    bio: 'Hi, we are Mirashya Homes! We provide curated boutique serviced apartments with private jacuzzis in North Goa. We pride ourselves on sparkling cleanliness and creating unforgettable holiday experiences.',
  },
  highlights: [
    {
      title: 'Outdoor entertainment',
      description: 'The pool and alfresco dining are great for summer trips.',
      icon: 'ShoppingBag',
    },
    {
      title: 'Designed for staying cool',
      description: 'Beat the heat with the A/C and ceiling fan.',
      icon: 'Fan',
    },
    {
      title: 'Self check-in',
      description: 'You can check in with the building staff.',
      icon: 'DoorOpen',
    },
  ],
  description: `🌴 Plan Your Relaxing Holiday at Amor De Goa by Mirashya Homes! ✨ Stay in this cozy 1BHK in the heart of Candolim, featuring a private jacuzzi 🛁 for the perfect unwind. Enjoy high-speed WiFi 💻, Smart TV 📺, pet-friendly comfort 🐾, and stylish interiors. Just minutes from Candolim Beach 🏖️, popular cafés, restaurants, and nightlife 🍸, it's ideal for couples, families, and remote workers looking for a tranquil escape.`,

  sleepingArrangements: [
    {
      room: 'Bedroom',
      bedType: '1 double bed',
      image: '/images/room-bedroom.jpg',
    },
    {
      room: 'Living room',
      bedType: '1 sofa',
      image: '/images/room-living.jpg',
    },
  ],

  amenities: [
    { name: 'Kitchen', category: 'Kitchen and dining', available: true, icon: 'Utensils' },
    { name: 'Wifi', category: 'Internet and office', available: true, icon: 'Wifi' },
    { name: 'Dedicated workspace', category: 'Internet and office', available: true, icon: 'Laptop' },
    { name: 'Free parking on premises', category: 'Parking and facilities', available: true, icon: 'Car' },
    { name: 'Pool', category: 'Outdoor', available: true, icon: 'Waves' },
    { name: 'Hot tub', category: 'Bathroom', available: true, icon: 'Bath' },
    { name: 'Pets allowed', category: 'Services', available: true, icon: 'PawPrint' },
    { name: 'Exterior security cameras on property', category: 'Home safety', available: true, icon: 'Camera' },
    { name: 'Carbon monoxide alarm', category: 'Home safety', available: false, icon: 'Ban' },
    { name: 'Smoke alarm', category: 'Home safety', available: false, icon: 'Ban' },
  ],

  ratingBreakdown: {
    cleanliness: 5.0,
    accuracy: 5.0,
    checkIn: 5.0,
    communication: 5.0,
    location: 4.8,
    value: 4.8,
  },

  reviewTags: [
    { emoji: '🛏️', name: 'Comfort', count: 6 },
    { emoji: '✅', name: 'Accuracy', count: 5 },
    { emoji: '🛁', name: 'Hot tub', count: 5 },
    { emoji: '🍧', name: 'Condition', count: 4 },
    { emoji: '🎁', name: 'Hospitality', count: 8 },
    { emoji: '🧴', name: 'Cleanliness', count: 4 },
    { emoji: '🧼', name: 'Amenities', count: 2 },
  ],

  reviews: [
    {
      id: 'rev-1',
      author: 'Amit',
      avatarLetter: 'A',
      rating: 5,
      date: '1 week ago',
      stayDuration: '2 months on Airbnb',
      content: 'Very helpful and responsive team. Safe and peaceful stay. loved everything',
    },
    {
      id: 'rev-2',
      author: 'Aheesh',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=128&h=128&q=80',
      rating: 5,
      date: '2 weeks ago',
      stayDuration: '3 years on Airbnb',
      content: 'We had a wonderful stay. The apartment was clean, comfortable, and the jacuzzi on the patio was the absolute highlight. Close to beach and cafes.',
    },
    {
      id: 'rev-3',
      author: 'Pooja',
      avatarLetter: 'P',
      rating: 5,
      date: '3 weeks ago',
      stayDuration: '1 year on Airbnb',
      content: 'Amazing location in Candolim! The staff was very polite and helpful. The jacuzzi was clean and warm. Definitely booking again.',
    },
    {
      id: 'rev-4',
      author: 'Karan',
      avatarLetter: 'K',
      rating: 5,
      date: '1 month ago',
      stayDuration: '4 years on Airbnb',
      content: 'Perfect vacation home for couples. High speed wifi was great for workation. Highly recommended!',
    },
  ],

  thingsToKnow: {
    houseRules: [
      { text: 'Check-in: 2:00 PM – 10:00 PM', icon: 'Clock' },
      { text: 'Checkout before 11:00 AM', icon: 'Clock' },
      { text: '3 guests maximum', icon: 'Users' },
      { text: 'No smoking inside apartment', icon: 'Ban' },
      { text: 'Pets allowed upon prior request', icon: 'PawPrint' },
    ],
    safetyAndProperty: [
      { text: 'Exterior security cameras on property', icon: 'Camera' },
      { text: 'Carbon monoxide alarm not reported', icon: 'AlertCircle' },
      { text: 'Smoke alarm not reported', icon: 'AlertCircle' },
    ],
    cancellationPolicy: [
      { text: 'Free cancellation before 17 October.', icon: 'CheckCircle' },
      { text: 'Review host’s full policy for details.', icon: 'Info' },
    ],
  },
};

export const LISTING_PHOTOS: Photo[] = [
  {
    id: 1,
    url: '/images/hero-1.jpg',
    thumbnail: '/images/hero-1.jpg',
    category: 'Living room',
    title: 'Private Patio & Alfresco Lounge',
    description: 'Outdoor patio with rattan seating, warm mood wall sconces, and private hydrotherapy jacuzzi tub.',
  },
  {
    id: 2,
    url: '/images/hero-2.jpg',
    thumbnail: '/images/hero-2.jpg',
    category: 'Living room',
    title: 'Outdoor Lounge Seating',
    description: 'Relaxing outdoor sitting area with comfortable cushions, coffee table, and lush planters.',
  },
  {
    id: 3,
    url: '/images/hero-3.jpg',
    thumbnail: '/images/hero-3.jpg',
    category: 'Jacuzzi',
    title: 'Private In-Suite Jacuzzi Tub',
    description: 'Heated hydrotherapy jacuzzi tub set in rich wooden decking with ambient sconce lighting.',
  },
  {
    id: 4,
    url: '/images/hero-4.jpg',
    thumbnail: '/images/hero-4.jpg',
    category: 'Bedroom',
    title: 'Master Bedroom',
    description: 'Cozy bedroom with double bed, crisp white linens, wardrobe, ceiling fan, and patio door.',
  },
  {
    id: 5,
    url: '/images/hero-5.jpg',
    thumbnail: '/images/hero-5.jpg',
    category: 'Exterior',
    title: 'Amor De Goa by Mirashya Complex',
    description: 'Mirashya apartment complex with terracotta roof, landscaped palm garden, and swimming pool.',
  },
  {
    id: 6,
    url: '/images/room-living.jpg',
    thumbnail: '/images/room-living.jpg',
    category: 'Living room',
    title: 'Cozy Living Room with Sofa',
    description: 'Comfortable living area with orange couch, ceiling fan, wooden center table, and dining space.',
  },
  {
    id: 7,
    url: '/images/room-bedroom.jpg',
    thumbnail: '/images/room-bedroom.jpg',
    category: 'Bedroom',
    title: 'Bedroom Suite View',
    description: 'Master bedroom with natural sunlight, bedside lamp, and direct access to patio jacuzzi.',
  },
];
